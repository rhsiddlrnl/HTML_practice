const stage1 = {
  name: "Stage 1",
  playerStart: { x: 100, y: 430 }, // 플레이어 바닥선 기준
  goal: { x: 700, y: 480 },
  groundY: 480,
  platforms: [
  ],
  obstacles: [
  ],
  lavas: [
  ],
  missiles: [
    { x: 100, y: 100, speed: 2, delay : 3 }
  ]
};
